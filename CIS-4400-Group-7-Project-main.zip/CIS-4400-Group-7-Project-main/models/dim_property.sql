{{
    config(
        materialized='table'
    )
}}

WITH property_cte AS (
    SELECT
    PROPERTY_ID as dim_property_id,
    PROPERTY_TYPE as property_type,
    LAND_TYPE as land_type,
    STATE as state,
    PROPERTY_CITY as property_city,
    PROPERTY_TOWNSHIP as property_township,
    PROPERTY_STREET_ADDRESS as property_street_address,
    PROPERTY_ZIP5 as property_zip,
    SOURCE_URL as source_url
    FROM HOUSINGDATA_RAW
)

SELECT * FROM property_cte