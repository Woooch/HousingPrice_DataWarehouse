{{
    config(
        materialized='table'
    )
}}

WITH facts_cte AS (
    SELECT
    SALE_ID,
    PROPERTY_ID,
    PROPERTY_COUNTY,
    SALE_PRICE as sale_price,
    TOTAL_APPRAISED_VALUE as total_appraised_value,
    TOTAL_ASSESSED_VALUE as total_assessed_value,
    BUILDING_APPRAISED_VALUE as building_appraised_value,
    BUILDING_ASSESSED_VALUE as building_assessed_value,
    BUILDING_NUM_UNITS as num_units,
    BUILDING_NUM_STORIES as num_stories,
    BUILDING_NUM_BEDS as num_beds,
    BUILDING_NUM_BATHS as num_baths,
    BUILDING_AREA_SQFT as building_area_sqft,
    LAND_ASSESSED_VALUE,
    LAND_AREA_ACRES,
    LAND_AREA_SQFT,
    PROPERTY_LAT as latitude,
    PROPERTY_LON as longitude
    FROM HOUSINGDATA_RAW
)

SELECT * FROM facts_cte