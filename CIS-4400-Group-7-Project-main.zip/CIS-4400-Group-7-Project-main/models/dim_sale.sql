
{{
    config(
        materialized='table'
    )
}}

WITH sale_cte AS (
    SELECT
    SALE_ID AS dim_sale_id,
    SALE_DATETIME as sale_datetime,
    BOOK as book,
    PAGE as page
    FROM HOUSINGDATA_RAW
)

SELECT * FROM sale_cte
