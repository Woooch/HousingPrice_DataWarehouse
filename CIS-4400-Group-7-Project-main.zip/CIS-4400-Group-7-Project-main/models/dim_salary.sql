{{
    config(
        materialized='table'
    )
}}

WITH salary_cte AS (
    SELECT
    COUNTYNAME as county,
    OCCUPATIONALAREA as profession,
    TYPICALANNUALSALARY as salary
    FROM MITLIVING_DIM
)

SELECT * FROM salary_cte

